

module("/FirstTest.js");

test("First.test()", function() {
    equals("first", First.test());
});

test("First.test() - fails", function() {
    equals("wrongResult", First.test());
});