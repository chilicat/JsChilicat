
var Second = {
    test : function() {
        return "second";
    }
};