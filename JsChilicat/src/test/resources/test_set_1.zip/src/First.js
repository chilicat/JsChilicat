
var First = {
    test: function() {
        return "first";
    }
};