
module("/foo/bar/SecondTest.js");

test("Second.test()", function() {
    equals("second", Second.test());
});